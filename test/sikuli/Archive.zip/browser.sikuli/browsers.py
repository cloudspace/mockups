from os import system

################
# Open Chrome
def chrome():
	system("open Google\ Chrome.app")
	type(Key.ESC)
	type(Key.ESC)
	type(Key.ESC)