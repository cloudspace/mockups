from sikuli.Sikuli import *

def disconnect():
	click("2.png")
	click("TurnAirPortO.png")
	wait("Q.png")
	wait(1)

def connect():
	click("Q.png")
	click("TurnAirPortO-1.png")
	wait("2.png")
	wait(1)